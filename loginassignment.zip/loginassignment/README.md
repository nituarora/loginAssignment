# Login Application

## Description
A simple login application with validation features.

## Available Scripts

In the project directory, you can run:

### `npm start`


